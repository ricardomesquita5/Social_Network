echo off

echo A INICIAR A LIGAÇÃO AO SERVIDOR IA

echo  VERIFICAR A LIGAÇÃO AO SERVIDOR VIA 'ping 10.9.21.163'


echo A INICIAR LIGAÇÃO VIA SSH
    ssh root@vs419.dei.isep.ipp.pt