no(1,100,200).
no(11,100,200).
no(12,100,200).
no(13,100,200).
no(14,100,200).
no(21,100,200).
no(22,100,200).
no(23,100,200).
no(24,100,200).
no(31,100,200).
no(32,100,200).
no(33,100,200).
no(34,100,200).
no(41,100,200).
no(42,100,200).
no(43,100,200).
no(44,100,200).
no(200,100,200).
no(51,100,200).
no(61,100,200).



ligacao(1,11,10,8).
ligacao(1,12,2,6).
ligacao(1,13,-3,-2).
ligacao(1,14,1,-5).
ligacao(11,21,5,7).
ligacao(11,22,2,-4).
ligacao(11,23,-2,8).
ligacao(11,24,6,0).
ligacao(12,21,4,9).
ligacao(12,22,-3,-8).
ligacao(12,23,2,4).
ligacao(12,24,-2,4).
ligacao(13,21,3,2).
ligacao(13,22,0,-3).
ligacao(13,23,5,9).
ligacao(13,24,-2, 4).
ligacao(14,21,2,6).
ligacao(14,22,6,-3).
ligacao(14,23,7,0).
ligacao(14,24,2,2).
ligacao(21,31,2,1).
ligacao(21,32,-2,3).
ligacao(21,33,3,5).
ligacao(21,34,4,2).
ligacao(22,31,5,-4).
ligacao(22,32,-1,6).
ligacao(22,33,2,1).
ligacao(22,34,2,3).
ligacao(23,31,4,-3).
ligacao(23,32,3,5).
ligacao(23,33,4,1).
ligacao(23,34,-2,-3).
ligacao(24,31,1,-5).
ligacao(24,32,1,0).
ligacao(24,33,3,-1).
ligacao(24,34,-1,5).
ligacao(31,41,2,4).
ligacao(31,42,6,3).
ligacao(31,43,2,1).
ligacao(31,44,2,1).
ligacao(32,41,2,3).
ligacao(32,42,-1,0).
ligacao(32,43,0,1).
ligacao(32,44,1,2).
ligacao(33,41,4,-1).
ligacao(33,42,-1,3).
ligacao(33,43,7,2).
ligacao(33,44,5,-3).
ligacao(34,41,3,2).
ligacao(34,42,1,-1).
ligacao(34,43,2,4).
ligacao(34,44,1,-2).
ligacao(41,200,2,0).
ligacao(42,200,7,-2).
ligacao(43,200,-2,4).
ligacao(44,200,-1,-3).
ligacao(1,51,6,2).
ligacao(51,61,7,3).
ligacao(61,200,2,4).
ligacao(24,34,-1,5).
ligacao(31,41,2,4).
ligacao(31,42,6,3).
ligacao(31,43,2,1).
ligacao(31,44,2,1).
ligacao(32,41,2,3).
ligacao(32,42,-1,0).
ligacao(32,43,0,1).
ligacao(32,44,1,2).
ligacao(33,41,4,-1).
ligacao(33,42,-1,3).
ligacao(33,43,7,2).
ligacao(33,44,5,-3).
ligacao(34,41,3,2).
ligacao(34,42,1,-1).
ligacao(34,43,2,4).
ligacao(34,44,1,-2).
ligacao(41,200,2,0).
ligacao(42,200,7,-2).
ligacao(43,200,-2,4).
ligacao(44,200,-1,-3).
ligacao(1,51,6,2).
ligacao(51,61,7,3).
ligacao(61,200,2,4).
ligacao(24,31,1,-5).
ligacao(24,32,1,0).
ligacao(24,33,3,-1).
ligacao(24,34,-1,5).
ligacao(31,41,2,4).
ligacao(31,42,6,3).
ligacao(31,43,2,1).
ligacao(31,44,2,1).
ligacao(32,41,2,3).
ligacao(32,42,-1,0).
ligacao(32,43,0,1).
ligacao(32,44,1,2).
ligacao(33,41,4,-1).
ligacao(33,42,-1,3).
ligacao(33,43,7,2).
ligacao(33,44,5,-3).
ligacao(34,41,3,2).
ligacao(34,42,1,-1).
ligacao(34,43,2,4).
ligacao(34,44,1,-2).
ligacao(41,200,2,0).
ligacao(42,200,7,-2).
ligacao(43,200,-2,4).
ligacao(44,200,-1,-3).
ligacao(1,51,6,2).
ligacao(51,61,7,3).
ligacao(61,200,2,4).
ligacao(24,34,-1,5).
ligacao(31,41,2,4).
ligacao(31,42,6,3).
ligacao(31,43,2,1).
ligacao(31,44,2,1).
ligacao(32,41,2,3).
ligacao(32,42,-1,0).
ligacao(32,43,0,1).
ligacao(32,44,1,2).
ligacao(33,41,4,-1).
ligacao(33,42,-1,3).
ligacao(33,43,7,2).
ligacao(33,44,5,-3).
ligacao(34,41,3,2).
ligacao(34,42,1,-1).
ligacao(34,43,2,4).
ligacao(34,44,1,-2).
ligacao(41,200,2,0).
ligacao(42,200,7,-2).
ligacao(43,200,-2,4).
ligacao(44,200,-1,-3).
ligacao(1,51,6,2).
ligacao(51,61,7,3).
ligacao(61,200,2,4).
ligacao(1,51,6,2).
ligacao(51,61,7,3).
ligacao(61,200,2,4).
ligacao(24,31,1,-5).
ligacao(24,32,1,0).
ligacao(24,33,3,-1).
ligacao(24,34,-1,5).
ligacao(31,41,2,4).
ligacao(31,42,6,3).
ligacao(31,43,2,1).
ligacao(31,44,2,1).
ligacao(32,41,2,3).
ligacao(32,42,-1,0).
ligacao(32,43,0,1).
ligacao(32,44,1,2).
ligacao(33,41,4,-1).
ligacao(33,42,-1,3).
ligacao(33,43,7,2).
ligacao(33,44,5,-3).
ligacao(34,41,3,2).
ligacao(34,42,1,-1).
ligacao(34,43,2,4).
ligacao(34,44,1,-2).
ligacao(41,200,2,0).
ligacao(42,200,7,-2).
ligacao(43,200,-2,4).
ligacao(44,200,-1,-3).
ligacao(1,51,6,2).
ligacao(51,61,7,3).
ligacao(61,200,2,4).
ligacao(24,34,-1,5).
ligacao(31,41,2,4).
ligacao(31,42,6,3).
ligacao(31,43,2,1).
ligacao(31,44,2,1).
ligacao(32,41,2,3).
ligacao(32,42,-1,0).
ligacao(32,43,0,1).
ligacao(32,44,1,2).
ligacao(33,41,4,-1).
ligacao(33,42,-1,3).
ligacao(33,43,7,2).
ligacao(33,44,5,-3).
ligacao(34,41,3,2).
ligacao(34,42,1,-1).
ligacao(34,43,2,4).
ligacao(34,44,1,-2).
ligacao(41,200,2,0).
ligacao(42,200,7,-2).
ligacao(43,200,-2,4).
ligacao(44,200,-1,-3).
ligacao(1,51,6,2).
ligacao(51,61,7,3).
ligacao(61,200,2,4).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

all_dfs(Nome1,Nome2,N,LCam):- get_time(T1),
    findall(Cam,depth_first(Nome1,Nome2,N,Cam),LCam),
    length(LCam,NLCam),
    get_time(T2),
    write(NLCam),write(' solucoes encontradas em '),
    T is T2-T1,write(T),write(' segundos'),nl,
    write('Lista de Caminhos possiveis: '),write(LCam),nl,nl.


plan_max(Orig,Dest,N,LCaminho_max):-
		get_time(Ti),
		(melhor_caminho_max(Orig,Dest,N);true),
		retract(melhor_sol_max(LCaminho_max,_)),
		get_time(Tf),
		T is Tf-Ti,
		write('Tempo de geracao da solucao:'),write(T),nl.

melhor_caminho_max(Orig,Dest,N):-
		asserta(melhor_sol_max(_,-1)),
		depth_first(Orig,Dest,N,LCaminho),
		atualiza_melhor_max(LCaminho),
		fail.

atualiza_melhor_max(LCaminho):-
		melhor_sol_max(_,N),
		calculaEstCaminho(LCaminho,C1),
		length(LCaminho,C2),
		C is C1 / C2,
		write(LCaminho), tab(1), write(C), nl,
		C>N,retract(melhor_sol_max(_,_)),
		asserta(melhor_sol_max(LCaminho,C)).


calculaEstCaminho([H|T],Val):-
	calculaEstCaminho2(H, T, 0, Val).

calculaEstCaminho2(_,[],Aux,Val):- Val is Aux,!.
calculaEstCaminho2(Ant, [H|T],Aux,Val):-
	estimativa(Ant, H, V),
	Sum is Aux + V,
	calculaEstCaminho2(H,T, Sum, Val).
 

connected2(X,Y,A,B) :- ligacao(X,Y,A,B).
connected2(X,Y,A,B) :- ligacao(Y,X,B,A).

next_node(Current, Next, Path) :-
    connected2(Current, Next, _,_),
    not(member(Next, Path)).

depth_first( Start, Goal, N, Path):-
	depth_first( Start, Goal, N,1,[Start], Path).

depth_first(Goal, Goal,_,_,_, [Goal]).
depth_first(Start, Goal,N,M, Visited, [Start|Path]) :-
    next_node(Start, Next_node, Visited),
	M1 is M +1, 
	M1 =< N,
    depth_first(Next_node, Goal, N, M1, [Next_node|Visited], Path).




estimativa(Act,X,Estimativa):-
    connected2(Act,X,V,_),
    write(Act), tab(1), write(X), tab(1), write('-->'),
    funcaoMulticriterio(V,X,Estimativa1), write(Estimativa1),nl, Estimativa is Estimativa1.
%

funcaoMulticriterio(Value, Nodo, Percentagem) :-
        percentagemForcaDeLigacao(Value, P1),
        likesEDislikes(Nodo, P2),
        Percentagem is P1 + P2.

percentagemForcaDeLigacao(Value, Percentagem):-
        Percentagem is Value * 50 / 100.

percentagemDiferencaLikeseDislikes(Value,Percentagem):- 
        (Value >= 200, Percentagem is 50,!); 
        (Value =< -200, Percentagem is 0,!);
        Percentagem is ((Value + 200) * 50) / 400.

diferencaLikeseDiskikes(Nodo1, Dif):-
    no(Nodo1, X,Y),
    Dif is X - Y.
%

likesEDislikes(Nodo, Percentagem) :-
    diferencaLikeseDiskikes(Nodo, P),
    percentagemDiferencaLikeseDislikes(P, Percentagem).