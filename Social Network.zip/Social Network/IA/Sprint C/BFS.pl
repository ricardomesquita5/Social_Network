ligacao(2,1,60,30).
ligacao(2,20,68,90).
ligacao(2,4,50,40).
ligacao(4,3,50,55).
ligacao(1,6,5,5).
ligacao(1,0,50,66).
ligacao(4,5,90,90).
ligacao(6,0,39,68).
ligacao(5,1,80,1).
ligacao(2,3,69,68).
ligacao(11,20,68,90).
ligacao(12,4,50,40).
ligacao(13,3,50,55).
ligacao(14,6,5,5).
ligacao(15,0,50,66).
ligacao(16,5,90,90).
ligacao(17,0,39,68).
ligacao(18,1,80,1).
ligacao(19,3,69,68).
ligacao(21,20,68,90).
ligacao(22,4,50,40).
ligacao(23,3,50,55).
ligacao(24,6,5,5).
ligacao(25,0,50,66).
ligacao(26,5,90,90).
ligacao(27,0,39,68).
ligacao(28,1,80,1).
ligacao(29,3,69,68).
ligacao(21,1,68,90).
ligacao(22,14,50,40).
ligacao(23,13,50,55).
ligacao(24,16,5,5).
ligacao(25,10,50,66).
ligacao(26,15,90,90).
ligacao(27,10,39,68).
ligacao(28,11,80,1).
ligacao(29,13,69,68).
ligacao(22,4,50,40).
ligacao(23,3,50,55).
ligacao(24,6,5,5).
ligacao(25,0,50,66).
ligacao(26,5,90,90).
ligacao(27,0,39,68).
ligacao(28,1,80,1).
ligacao(29,3,69,68).
ligacao(21,1,68,90).
ligacao(22,14,50,40).
ligacao(23,13,50,55).
ligacao(24,16,5,5).
ligacao(25,10,50,66).
ligacao(26,15,90,90).
ligacao(27,10,39,68).
ligacao(28,11,80,1).
ligacao(29,13,69,68).
ligacao(2,1,60,30).
ligacao(2,20,68,90).
ligacao(2,4,50,40).
ligacao(4,3,50,55).
ligacao(1,6,5,5).
ligacao(1,0,50,66).
ligacao(4,5,90,90).
ligacao(6,0,39,68).
ligacao(5,1,80,1).
ligacao(2,3,69,68).
ligacao(11,20,68,90).
ligacao(12,4,50,40).
ligacao(13,3,50,55).
ligacao(14,6,5,5).
ligacao(15,0,50,66).
ligacao(16,5,90,90).
ligacao(17,0,39,68).
ligacao(18,1,80,1).
ligacao(19,3,69,68).
ligacao(21,20,68,90).
ligacao(22,4,50,40).
ligacao(23,3,50,55).
ligacao(24,6,5,5).
ligacao(25,0,50,66).
ligacao(26,5,90,90).
ligacao(27,0,39,68).
ligacao(28,1,80,1).
ligacao(29,3,69,68).
ligacao(21,1,68,90).
ligacao(22,14,50,40).
ligacao(23,13,50,55).
ligacao(24,16,5,5).
ligacao(25,10,50,66).
ligacao(26,15,90,90).
ligacao(27,10,39,68).
ligacao(28,11,80,1).
ligacao(29,13,69,68).
ligacao(22,4,50,40).
ligacao(23,3,50,55).
ligacao(24,6,5,5).
ligacao(25,0,50,66).
ligacao(26,5,90,90).
ligacao(27,0,39,68).
ligacao(28,1,80,1).
ligacao(29,3,69,68).
ligacao(21,1,68,90).
ligacao(22,14,50,40).
ligacao(23,13,50,55).
ligacao(24,16,5,5).
ligacao(25,10,50,66).
ligacao(26,15,90,90).
ligacao(27,10,39,68).
ligacao(28,11,80,1).
ligacao(29,13,69,68).
ligacao(4,3,50,55).
ligacao(1,6,5,5).
ligacao(1,0,50,66).
ligacao(4,5,90,90).
ligacao(6,0,39,68).
ligacao(5,1,80,1).
ligacao(2,3,69,68).
ligacao(11,20,68,90).
ligacao(12,4,50,40).
ligacao(13,3,50,55).
ligacao(14,6,5,5).
ligacao(15,0,50,66).
ligacao(16,5,90,90).
ligacao(17,0,39,68).
ligacao(18,1,80,1).
ligacao(19,3,69,68).
ligacao(21,20,68,90).
ligacao(22,4,50,40).
ligacao(23,3,50,55).
ligacao(24,6,5,5).
ligacao(25,0,50,66).
ligacao(26,5,90,90).
ligacao(27,0,39,68).
ligacao(28,1,80,1).
ligacao(29,3,69,68).
ligacao(21,1,68,90).
ligacao(22,14,50,40).
ligacao(23,13,50,55).
ligacao(24,16,5,5).
ligacao(25,10,50,66).
ligacao(26,15,90,90).
ligacao(27,10,39,68).
ligacao(28,11,80,1).
ligacao(29,13,69,68).
ligacao(22,4,50,40).
ligacao(23,3,50,55).
ligacao(24,6,5,5).
ligacao(25,0,50,66).
ligacao(26,5,90,90).
ligacao(27,0,39,68).
ligacao(28,1,80,1).
ligacao(29,3,69,68).
ligacao(21,1,68,90).
ligacao(22,14,50,40).
ligacao(23,13,50,55).
ligacao(24,16,5,5).
ligacao(25,10,50,66).
ligacao(26,15,90,90).
ligacao(27,10,39,68).
ligacao(28,11,80,1).
ligacao(29,13,69,68).
ligacao(4,3,50,55).
ligacao(1,6,5,5).
ligacao(1,0,50,66).
ligacao(4,5,90,90).
ligacao(6,0,39,68).
ligacao(5,1,80,1).
ligacao(2,3,69,68).
ligacao(11,20,68,90).
ligacao(12,4,50,40).
ligacao(13,3,50,55).
ligacao(14,6,5,5).
ligacao(15,0,50,66).
ligacao(16,5,90,90).
ligacao(17,0,39,68).
ligacao(18,1,80,1).
ligacao(19,3,69,68).
ligacao(21,20,68,90).
ligacao(22,4,50,40).
ligacao(23,3,50,55).
ligacao(24,6,5,5).
ligacao(25,0,50,66).
ligacao(26,5,90,90).
ligacao(27,0,39,68).
ligacao(28,1,80,1).
ligacao(29,3,69,68).
ligacao(21,1,68,90).
ligacao(22,14,50,40).
ligacao(23,13,50,55).
ligacao(24,16,5,5).
ligacao(25,10,50,66).
ligacao(26,15,90,90).
ligacao(27,10,39,68).
ligacao(28,11,80,1).
ligacao(29,13,69,68).
ligacao(22,4,50,40).
ligacao(23,3,50,55).
ligacao(24,6,5,5).
ligacao(25,0,50,66).
ligacao(26,5,90,90).
ligacao(27,0,39,68).
ligacao(28,1,80,1).
ligacao(29,3,69,68).
ligacao(21,1,68,90).
ligacao(22,14,50,40).
ligacao(23,13,50,55).
ligacao(24,16,5,5).
ligacao(25,10,50,66).
ligacao(26,15,90,90).
ligacao(27,10,39,68).
ligacao(28,11,80,1).
ligacao(29,13,69,68).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

all_dfs(Nome1,Nome2,N,LCam):- get_time(T1),
    findall(Cam,depth_first(Nome1,Nome2,N,Cam),LCam),
    length(LCam,NLCam),
    get_time(T2),
    write(NLCam),write(' solucoes encontradas em '),
    T is T2-T1,write(T),write(' segundos'),nl,
    write('Lista de Caminhos possiveis: '),write(LCam),nl,nl.


plan_max(Orig,Dest,N,LCaminho_max):- get_time(T1),
	(melhor_caminho_max(Orig,Dest,N);true),
	retract(melhor_sol_max(LCaminho_max,_)),
	get_time(T2),
	T is T2-T1,write(T),write(' segundos'),nl,
    write('Lista de Caminhos possiveis: '),write(LCam),nl,nl.
		

melhor_caminho_max(Orig,Dest,N):-
		asserta(melhor_sol_max(_,-1)),
		depth_first(Orig,Dest,N,LCaminho),
		atualiza_melhor_max(LCaminho),
		fail.

atualiza_melhor_max(LCaminho):-
		melhor_sol_max(_,N),
		length(LCaminho,C),
		C>N,retract(melhor_sol_max(_,_)),
		asserta(melhor_sol_max(LCaminho,C)).
 

connected2(X,Y,A,B) :- ligacao(X,Y,A,B).
connected2(X,Y,A,B) :- ligacao(Y,X,B,A).

next_node(Current, Next, Path) :-
    connected2(Current, Next, _,_),
    not(member(Next, Path)).

depth_first( Start, Goal, N, Path):-
	depth_first( Start, Goal, N,1,[Start], Path).

depth_first(Goal, Goal,_,_,_, [Goal]).
depth_first(Start, Goal,N,M, Visited, [Start|Path]) :-
    next_node(Start, Next_node, Visited),
	M1 is M +1, 
	M1 =< N,
    depth_first(Next_node, Goal, N, M1, [Next_node|Visited], Path).