node(a,45,95).
node(b,90,95).
node(c,1500,850).
node(d,40,80).
node(e,70,80).
node(f,25,65).
node(g,65,65).
node(h,45,55).
node(i,5,50).
node(j,80,50).
node(l,65,45).
node(m,5,40).
node(n,55,30).
node(o,80,30).
node(p,25,15).
node(q,80,15).
node(r,55,10).


edge(g,j,16).
edge(j,g,16).
edge(l,e,3).
edge(e,l,3).
edge(j,h,50).
edge(h,j,50).
edge(a,r,16).
edge(r,a,16).
edge(r,i,3).
edge(i,r,50).
edge(f,p,16).
edge(p,f,3).
edge(p,m,50).
edge(m,p,50).


edge(a,b,16).
edge(b,a,16).
edge(b,e,3).
edge(e,b,3).
edge(a,e,50).
edge(e,a,50).
edge(a,c,16).
edge(c,a,16).
edge(c,p,3).
edge(p,c,50).
edge(a,p,16).
edge(p,a,3).
edge(b,c,50).
edge(c,b,50).


edge(a,b,16).
edge(b,a,16).
edge(b,e,3).
edge(e,b,3).
edge(a,e,50).
edge(e,a,50).
edge(a,c,16).
edge(c,a,16).
edge(c,p,3).
edge(p,c,50).
edge(a,p,16).
edge(p,a,3).
edge(b,c,50).
edge(c,b,50).

edge(g,j,16).
edge(j,g,16).
edge(l,e,3).
edge(e,l,3).
edge(j,h,50).
edge(h,j,50).
edge(a,r,16).
edge(r,a,16).
edge(r,i,3).
edge(i,r,50).
edge(f,p,16).
edge(p,f,3).
edge(p,m,50).
edge(m,p,50).


edge(a,b,16).
edge(b,a,16).
edge(b,e,3).
edge(e,b,3).
edge(a,e,50).
edge(e,a,50).
edge(a,c,16).
edge(c,a,16).
edge(c,p,3).
edge(p,c,50).
edge(a,p,16).
edge(p,a,3).
edge(b,c,50).
edge(c,b,50).


edge(a,b,16).
edge(b,a,16).
edge(b,e,3).
edge(e,b,3).
edge(a,e,50).
edge(e,a,50).
edge(a,c,16).
edge(c,a,16).
edge(c,p,3).
edge(p,c,50).
edge(a,p,16).
edge(p,a,3).
edge(b,c,50).
edge(c,b,50).
edge(g,j,16).
edge(j,g,16).
edge(l,e,3).
edge(e,l,3).
edge(j,h,50).
edge(h,j,50).
edge(a,r,16).
edge(r,a,16).
edge(r,i,3).
edge(i,r,50).
edge(f,p,16).
edge(p,f,3).
edge(p,m,50).
edge(m,p,50).


edge(a,b,16).
edge(b,a,16).
edge(b,e,3).
edge(e,b,3).
edge(a,e,50).
edge(e,a,50).
edge(a,c,16).
edge(c,a,16).
edge(c,p,3).
edge(p,c,50).
edge(a,p,16).
edge(p,a,3).
edge(b,c,50).
edge(c,b,50).


edge(a,b,16).
edge(b,a,16).
edge(b,e,3).
edge(e,b,3).
edge(a,e,50).
edge(e,a,50).
edge(a,c,16).
edge(c,a,16).
edge(c,p,3).
edge(p,c,50).
edge(a,p,16).
edge(p,a,3).
edge(b,c,50).
edge(c,b,50).edge(g,j,16).
edge(j,g,16).
edge(l,e,3).
edge(e,l,3).
edge(j,h,50).
edge(h,j,50).
edge(a,r,16).
edge(r,a,16).
edge(r,i,3).
edge(i,r,50).
edge(f,p,16).
edge(p,f,3).
edge(p,m,50).
edge(m,p,50).


edge(a,b,16).
edge(b,a,16).
edge(b,e,3).
edge(e,b,3).
edge(a,e,50).
edge(e,a,50).
edge(a,c,16).
edge(c,a,16).
edge(c,p,3).
edge(p,c,50).
edge(a,p,16).
edge(p,a,3).
edge(b,c,50).
edge(c,b,50).


edge(a,b,16).
edge(b,a,16).
edge(b,e,3).
edge(e,b,3).
edge(a,e,50).
edge(e,a,50).
edge(a,c,16).
edge(c,a,16).
edge(c,p,3).
edge(p,c,50).
edge(a,p,16).
edge(p,a,3).
edge(b,c,50).
edge(c,b,50).edge(g,j,16).
edge(j,g,16).
edge(l,e,3).
edge(e,l,3).
edge(j,h,50).
edge(h,j,50).
edge(a,r,16).
edge(r,a,16).
edge(r,i,3).
edge(i,r,50).
edge(f,p,16).
edge(p,f,3).
edge(p,m,50).
edge(m,p,50).


edge(a,b,16).
edge(b,a,16).
edge(b,e,3).
edge(e,b,3).
edge(a,e,50).
edge(e,a,50).
edge(a,c,16).
edge(c,a,16).
edge(c,p,3).
edge(p,c,50).
edge(a,p,16).
edge(p,a,3).
edge(b,c,50).
edge(c,b,50).


edge(a,b,16).
edge(b,a,16).
edge(b,e,3).
edge(e,b,3).
edge(a,e,50).
edge(e,a,50).
edge(a,c,16).
edge(c,a,16).
edge(c,p,3).
edge(p,c,50).
edge(a,p,16).
edge(p,a,3).
edge(b,c,50).
edge(c,b,50).edge(g,j,16).
edge(j,g,16).
edge(l,e,3).
edge(e,l,3).
edge(j,h,50).
edge(h,j,50).
edge(a,r,16).
edge(r,a,16).
edge(r,i,3).
edge(i,r,50).
edge(f,p,16).
edge(p,f,3).
edge(p,m,50).
edge(m,p,50).


edge(a,b,16).
edge(b,a,16).
edge(b,e,3).
edge(e,b,3).
edge(a,e,50).
edge(e,a,50).
edge(a,c,16).
edge(c,a,16).
edge(c,p,3).
edge(p,c,50).
edge(a,p,16).
edge(p,a,3).
edge(b,c,50).
edge(c,b,50).


edge(a,b,16).
edge(b,a,16).
edge(b,e,3).
edge(e,b,3).
edge(a,e,50).
edge(e,a,50).
edge(a,c,16).
edge(c,a,16).
edge(c,p,3).
edge(p,c,50).
edge(a,p,16).
edge(p,a,3).
edge(b,c,50).
edge(c,b,50).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

bestfs1(Orig, Dest, Cam, Custo, N):-
    get_time(Ti),
    bestfs12(Dest, [[Orig]], Cam, Custo, N),
    get_time(Tf),
	T is Tf-Ti,
	write('Tempo de geracao da solucao:'),write(T),nl.

bestfs12(Dest, [[Dest|T]|_], Cam, Custo, _):- 
    reverse([Dest|T], Cam),
    calcula_custo(Cam, Custo).

bestfs12(Dest, [[Dest|_]|LLA2], Cam, Custo, N):- 
    !,
    bestfs12(Dest, LLA2, Cam, Custo, N).

bestfs12(Dest, LLA, Cam, Custo, N):-
    member1(LA, LLA, LLA1),
    LA = [Act|_],
    ((Act == Dest, !, bestfs12(Dest, [LA|LLA1], Cam, Custo, N))
     ;
     (
      length(LA, NLA), NLA =< N,
      findall((CX, [X|LA]), (edge(Act, X, CX),
      \+member(X, LA)), Novos),
      Novos \== [], !,
      sort(0, @>=, Novos, NovosOrd),
      retira_custos(NovosOrd, NovosOrd1),
      append(NovosOrd1, LLA1, LLA2),
      bestfs12(Dest, LLA2, Cam, Custo, N)
     )).

member1(LA, [LA|LAA], LAA).
member1(LA, [_|LAA], LAA1):- member1(LA, LAA, LAA1).

retira_custos([], []).
retira_custos([(_,LA)|L], [LA|L1]):- retira_custos(L, L1).

calcula_custo([Act, X], C):-!, edge(Act, X, C1), edge(X, Act, OC1), C is C1 + OC1.
calcula_custo([Act, X|L], S):- calcula_custo([X|L], S1), 
                                edge(Act, X, C), edge(X, Act, OC), S is S1 + C + OC.