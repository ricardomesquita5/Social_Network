echo off

echo A INICIAR BUILD E TESTES DA APLICACAO

dotnet build

echo PROCESSO FINALIDADO

exit
