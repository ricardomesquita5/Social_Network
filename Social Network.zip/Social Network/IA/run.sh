echo off

echo A INICIAR A APLICACAO

dotnet run