import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ObterPedidosLigacaoPendentesComponent } from './obter-pedidos-ligacao-pendentes/obter-pedidos-ligacao-pendentes.component';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class PedidoLigacaoModule { }
