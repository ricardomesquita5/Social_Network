export const urlBaseMDR = "https://10.9.20.237:30237/api/";

export const urlBaseMDP = "http://10.9.21.82:10338/api/";

export const urlBaseIA = "http://10.9.21.163:10419/api/";

// export const urlBaseMDR = "https://localhost:30237/api/";
//
// export const urlBaseMDP = "http://localhost:10338/api/";
//
// export const urlBaseIA = "http://localhost:10419/api/";
