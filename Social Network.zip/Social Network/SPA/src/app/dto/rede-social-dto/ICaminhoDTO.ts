export interface ICaminhoDTO{
  caminho: Array<string>;
  valor: number;
}
