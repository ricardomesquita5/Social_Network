export interface ITamanhoDTO{
  users:Array<string>;
  tamanho:number;
}
