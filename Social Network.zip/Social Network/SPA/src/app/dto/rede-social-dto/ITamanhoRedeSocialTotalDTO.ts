export interface ITamanhoRedeSocialTotalDTO{
  tamanhoRedeSocialCompleto:number;
}
