export default interface IRedeSocialPerspetivaDTO {
  userId: string;
  n: number;
  users: string[];
  forcaLigacao: number[][],
  tags: string[][]

}
