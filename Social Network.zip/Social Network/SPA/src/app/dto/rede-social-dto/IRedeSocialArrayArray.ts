import IRelacaoDTO from "../relacao-dto/IRelacaoDTO";

export default interface IRedeSocialArrayArray {
  rede: Array<Array<IRelacaoDTO>>;
}
