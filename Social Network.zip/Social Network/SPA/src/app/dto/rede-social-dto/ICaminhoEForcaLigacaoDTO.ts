export interface ICaminhoEForcaLigacaoDTO {
  caminho: Array<string>;
  valor: number;
  forcasLigacaoDestinoOrigem:Array<number>;
  forcasLigacaoOrigemDestino:Array<number>;
}
