export default interface IRedeSocialGetDTO {
  nivel: number;
  utilizadorDestino: string;
  valorMinimo: number;
}
