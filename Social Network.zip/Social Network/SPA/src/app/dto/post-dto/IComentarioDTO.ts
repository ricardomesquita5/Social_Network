export interface IComentarioDTO{
  reacao: string;
  texto: string;
  tags: string;
  utilizador: string;
  post: string;
}
