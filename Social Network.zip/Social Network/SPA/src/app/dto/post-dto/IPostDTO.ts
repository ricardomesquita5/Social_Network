export interface IPostDTO{
  texto:string;
  tags:Array<string>;
  utilizador:string;
}
