export interface IUtilizadorIdDTO{
 email:string;
}
