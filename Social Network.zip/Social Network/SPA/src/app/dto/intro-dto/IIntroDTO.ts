export default interface IIntroDTO{
  introducaoId :string;
  descricao :string;
  utilizadorOrigem:string
  utilizadorIntermediario:string;
  utilizadorDestino :string;
  estadoIntro:string;
  listTags:string;
}
