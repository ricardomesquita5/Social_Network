export default interface IUtilizadorDTO{
  nomeUtilizador: string;
  breveDescricaoUtilizador: string;
  email: string;
  numeroDeTelefoneUtilizador: string;
  dataDeNascimentoUtilizador: string;
  perfilFacebookUtilizador: string;
  perfilLinkedinUtilizador: string;
  estadoEmocionalUtilizador: number;
  tagsUtilizador: string;
  urlImagem: string;
  cidadePaisResidencia: string;
  dataModificacaoEstado: string;
  passwordU: string;
}
