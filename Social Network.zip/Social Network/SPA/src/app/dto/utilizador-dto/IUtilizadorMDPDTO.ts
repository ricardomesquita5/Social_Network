export interface IUtilizadorMDPDTO{
  email:string;
  nome:string;
}
