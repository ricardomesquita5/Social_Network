export interface GrupoDTO{
  listaUsers:Array<string>;
}
