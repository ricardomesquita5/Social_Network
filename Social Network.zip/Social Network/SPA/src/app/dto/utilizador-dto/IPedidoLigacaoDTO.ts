export default interface IPedidoLigacaoDTO {
  dest: string;
  forca: number;
  tagsL: string;
}
