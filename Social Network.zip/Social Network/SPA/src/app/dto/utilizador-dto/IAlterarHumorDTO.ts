export default interface IAlterarHumorDTO {
  estadoEmocionalUtilizador: number;
}
