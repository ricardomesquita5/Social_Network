export default interface IUtilizadoresSugestoesDTO{
 nomeUtilizador:string;
 email:string;
}
