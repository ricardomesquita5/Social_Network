export interface IUtilizadorEraseMDRDTO {
  email:string;
  nome:string;
}
