export default interface IPesquisaUtilizadorDTO {
  emailD: string;
  cidadePaisD: string;
  nomeD: string;
}
