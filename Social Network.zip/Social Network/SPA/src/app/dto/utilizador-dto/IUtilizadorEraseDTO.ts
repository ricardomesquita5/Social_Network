export interface IUtilizadorEraseDTO{
  old:string;
  novo:string;
}
