export interface IUtilizadorTagsDTO{
  tags:string;
}
