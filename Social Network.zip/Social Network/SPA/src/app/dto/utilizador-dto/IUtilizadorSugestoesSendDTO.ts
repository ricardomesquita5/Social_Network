export interface IUtilizadorSugestoesSendDTO{
  nomeUtilizador:string;
  email:string;
}
