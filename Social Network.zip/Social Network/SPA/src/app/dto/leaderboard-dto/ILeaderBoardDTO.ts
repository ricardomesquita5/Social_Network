export interface ILeaderBoardDTO{
  email:string;
  valor:number;
}
