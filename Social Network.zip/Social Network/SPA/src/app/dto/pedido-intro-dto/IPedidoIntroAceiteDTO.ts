export interface IPedidoIntroAceiteDTO{
  id:string;
  descricaoPedido:string;
  emailOrigem:string;
  emailIntermedio:string;
  emailDestino:string;
  estadoPedidoIntroducao:number;
  forca:number;
  tags:string;
  descricaoIntroducao:string;
}
