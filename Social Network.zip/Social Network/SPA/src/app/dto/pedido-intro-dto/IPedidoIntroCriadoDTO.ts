export default interface IPedidoIntroCriadoDTO {
  descricao: string;
  emailIntermedio: string;
  emailDestino: string;
  estadoPedidoIntroducao: number;
  forca: number;
  tags: string;
}
