export interface IIntermediarioDTO{
  email:string;
}
