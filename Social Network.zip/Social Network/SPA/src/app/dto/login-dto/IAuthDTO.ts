export interface IAuthDTO{
  email: string;
}
