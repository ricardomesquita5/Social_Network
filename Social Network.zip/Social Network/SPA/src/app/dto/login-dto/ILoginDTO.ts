export interface ILoginDTO{
  email:string;
  password:string;
}
