export interface IRelacaoTagsDTO{
  tags:string;
}
