export default interface IRelacaoCriacaoDTO {
  forca:number;
  tags: string;
}
