export default interface IRelacaoDTO {
  relacaoId: string;
  utilizadorOrigem: string;
  utilizadorDestino: string;
  forcaLigacaoOrigDest: string;
  forcaLigacaoDestOrig: string;
  tagsRelacaoAB:string;
  tagsRelacaoBA:string;

}
