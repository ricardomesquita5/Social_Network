export default interface IPedidoLigacaoTodaDTO {
  id: string;
  emailOrigem: string;
  emailDestino: string;
  forcaRelacao: number;
  tags: string;
}
