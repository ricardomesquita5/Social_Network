export interface IPedidoLigacaoAceiteDTO{
  forca:number;
  tagsL:string;
}
