import IPedidoIntroDTO from "../../dto/pedido-intro-dto/IPedidoIntroDTO";

/*export class UtilizadorMap{
  public static toDTO(id: string, descricao: string, origem: string,
                      intermedio: string, destino: string, forca: number,
                      listTags: string): IPedidoIntroDTO {
    return {
      id: id,
      descricao: descricao,
      origem: origem,
      intermedio: intermedio,
      destino: destino,
      estado: 0,
      forca: forca,
      listTags: listTags,
    } as IPedidoIntroDTO;
  }
}*/
