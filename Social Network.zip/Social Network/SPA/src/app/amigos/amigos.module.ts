import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AmigosComunsEntreDoisUsersComponent } from './amigos-comuns-entre-dois-users/amigos-comuns-entre-dois-users.component';



@NgModule({
  declarations: [
  ],
  imports: [
    CommonModule
  ]
})
export class AmigosModule { }
