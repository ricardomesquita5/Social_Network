echo A INICIAR A LIGAÇÃO AO SERVIDOR SPA

echo  VERIFICAR A LIGAÇÃO AO SERVIDOR COM 'ping 10.9.21.156'

echo A INICIAR LIGAÇÃO VIA SSH

    ssh root@vs412.dei.isep.ipp.pt
