echo off

echo ##### A INSTALAR A VERSAO COMPATIVEL #####

nvm install 16.13.1

echo ##### A TROCAR PARA A VERSAO COMPATIVEL #####

nvm use 16.13.1

exit
