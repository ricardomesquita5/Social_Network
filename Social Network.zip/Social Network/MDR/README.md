# LAPR5-G61

## WIKI

Clica [AQUI](https://bitbucket.org/antoniodbf261201/21s5_dk_61_api/wiki/Home) para aceder à WIKI.



## EQUIPA

| Número  | Nome              |
|---------|-------------------|
| 1190402 | António Fernandes |
| 1191045 | Rui Soares        |
| 1190742 | Joao Pereira      |
| 1120354 | Emanuel Salvadinho|
| 1190995 | Ricardo Mesquita  |

