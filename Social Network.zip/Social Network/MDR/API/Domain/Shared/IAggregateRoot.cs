namespace DDDSample1.Domain.Shared
{
    public interface IAggregateRoot
    {
    }
}