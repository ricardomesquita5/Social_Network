# MAQUINA VIRTUAL -> PROCEDIMENTO:

ACEDER VIA TERMINAL:

ssh root@vs237.dei.isep.ipp.pt

7n0E7xVTC5uw

cd api/21s5_dk_61_api/API

git pull && build-all && dotnet-run