namespace DDDSample1.Infrastructure
{
    internal class SchemaNames
    {
        internal const string DDDSample1 = "ddd";
    }
}