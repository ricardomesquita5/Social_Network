echo off

echo A INICIAR A LIGAÇÃO AO SERVIDOR MDR

echo  VERIFICAR A LIGAÇÃO AO SERVIDOR através de 'ping 10.9.20.237'


echo A INICIAR LIGAÇÃO VIA SSH

    ssh root@vs237.dei.isep.ipp.pt
