echo off

echo A TESTAR A APLICACAO

dotnet test TESTS

echo TESTES CONCLUIDOS

exit