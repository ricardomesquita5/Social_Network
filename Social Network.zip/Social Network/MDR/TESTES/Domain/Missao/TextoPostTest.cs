﻿using System;
using DDDNetCore.Domain.Post;
using NUnit.Framework;

namespace api.tests.Domain.Post{
    public class TextoPostTest
    {
         
}