echo off

echo A TESTAR A APLICACAO

 ng e2e &&  npx cypress open

echo TESTES CONCLUIDOS

exit
