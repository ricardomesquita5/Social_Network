echo off

echo ##### A INSTALAR A VERSAO COMPATIVEL #####

nvm install 10.15.0

echo ##### A TROCAR PARA A VERSAO COMPATIVEL #####

nvm use 10.15.0


