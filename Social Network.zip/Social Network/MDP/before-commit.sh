echo off

echo A INICIAR OS PROCEDIMENTOS ANTERIORES AO COMMIT

git pull && npm run-script build

echo PRONTO PARA EFETUAR O COMMIT

exit
