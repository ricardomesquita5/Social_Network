export interface IUtilizadorPersistence {
  _id: string;
  email: string;
  nome: string;
}
