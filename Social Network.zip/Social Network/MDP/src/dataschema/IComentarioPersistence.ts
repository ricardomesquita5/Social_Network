export interface IComentarioPersistence {
  _id: string;
  texto: string;
  tags: string;
  reacao: string;
  utilizador: string;
  post: string;
}
