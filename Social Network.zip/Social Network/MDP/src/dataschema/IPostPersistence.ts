export interface IPostPersistence {
  _id: string;
  texto: string;
  tags: string;
  utilizador: string;
}
