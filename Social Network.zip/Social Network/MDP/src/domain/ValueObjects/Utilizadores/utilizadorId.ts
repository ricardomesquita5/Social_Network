import { UniqueEntityID } from '../../../core/domain/UniqueEntityID';

export class UtilizadorId extends UniqueEntityID {}
