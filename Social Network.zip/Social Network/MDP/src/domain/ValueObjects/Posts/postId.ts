import { UniqueEntityID } from '../../../core/domain/UniqueEntityID';

export class PostId extends UniqueEntityID {}
