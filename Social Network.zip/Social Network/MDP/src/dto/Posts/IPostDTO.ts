export interface IPostDTO {
  //id: string;
  texto: string;
  tags: string;
  utilizador: string;
}
