export default interface IUtilizadorEraseDTO {
  old: string;
  novo: string;
}
