export default interface IUtilizadorDTO {
  id: string;
  email: string;
  nome: string;
}
