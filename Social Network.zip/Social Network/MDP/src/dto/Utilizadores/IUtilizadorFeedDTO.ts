export default interface IUtilizadorFeedDTO {
  post: string;
  postUser: string;
  postId: string;
  comentarios: [string];
}
