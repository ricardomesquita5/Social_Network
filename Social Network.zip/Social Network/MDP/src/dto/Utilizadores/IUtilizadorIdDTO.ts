export default interface IUtilizadorIdDTO {
  email: string;
}
