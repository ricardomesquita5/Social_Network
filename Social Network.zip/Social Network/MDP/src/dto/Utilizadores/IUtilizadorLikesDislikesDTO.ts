export default interface IUtilizadorLikesDislikesDTO {
  likes: number;
  dislikes: number;
}
