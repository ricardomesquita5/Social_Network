export default interface IUtilizadorLikeDislikeDTO {
  valor: number;
}
