export default interface IUtilizadorOrDestDTO {
  emailOrigem: string;
  emailDestino: string;
}
