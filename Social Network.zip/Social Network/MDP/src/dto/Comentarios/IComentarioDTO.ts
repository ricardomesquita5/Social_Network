export interface IComentarioDTO {
  //id: string;
  reacao: string;
  texto: string;
  tags: string;
  utilizador: string;
  post: string;
}
