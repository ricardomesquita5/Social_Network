echo off

echo A INICIAR BUILD E TESTES DA APLICACAO

npm run-script build

echo PROCESSO FINALIDADO

exit
