echo off


echo  A TROCAR PARA A VERSAO COMPATIVEL

  nvm use 10.15.0

echo A INICIAR A APLICACAO

  npm run start
