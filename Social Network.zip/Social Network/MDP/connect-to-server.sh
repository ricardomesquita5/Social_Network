echo A INICIAR A LIGAÇÃO AO SERVIDOR MDP

echo VERIFICAR A LIGAÇÃO AO SERVIDOR COM 'ping 10.9.21.82'


echo A INICIAR LIGAÇÃO VIA SSH

    ssh root@vs338.dei.isep.ipp.pt
